
// This file replaces the .env file for configuration.
// Replace the values below with your actual Supabase project details found in Project Settings > API.

export const supabaseConfig = {
  // Example: https://abcdefghijklm.supabase.co
  supabaseUrl: "https://alqlejlrkhvqudpifiio.supabase.co", 
  
  // Example: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
  supabaseAnonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFscWxlamxya2h2cXVkcGlmaWlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM4MzkyMjUsImV4cCI6MjA3OTQxNTIyNX0.35Sfs3Jrpoyd2N7D3sQpWfcmelEltkl7eBGu6BJeZ-g" 
};